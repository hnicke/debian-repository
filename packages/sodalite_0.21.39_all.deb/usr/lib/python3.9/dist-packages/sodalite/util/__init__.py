from .version import VERSION

__all__ = [VERSION]
